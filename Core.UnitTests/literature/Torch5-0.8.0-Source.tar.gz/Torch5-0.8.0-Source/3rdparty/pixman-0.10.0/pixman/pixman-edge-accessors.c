
#define PIXMAN_FB_ACCESSORS

#include "pixman-edge.c"
