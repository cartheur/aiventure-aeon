require "torch"
require "librandom"