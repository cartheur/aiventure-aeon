#ifndef TORCH_TENSOR_MATH_INC
#define TORCH_TENSOR_MATH_INC

#include "Tensor.h"

void torch_TensorMath_init(lua_State *L);

#endif
