/* Storage type */
#define STORAGE_T_(TYPE) TH##TYPE##Storage
#define STORAGE_T(TYPE) STORAGE_T_(TYPE)
#define STORAGE STORAGE_T(CAP_TYPE)

/* Function name for a Storage */
#define STORAGE_FUNC_TN_(TYPE,NAME) TH##TYPE##Storage_##NAME
#define STORAGE_FUNC_TN(TYPE, NAME) STORAGE_FUNC_TN_(TYPE,NAME) 
#define STORAGE_FUNC(NAME) STORAGE_FUNC_TN(CAP_TYPE, NAME)

/* Wrapper function name for a Storage */
#define W_MAP_STORAGE_FUNC_TN_(TYPE, NAME) torch_##TYPE##MapStorage_##NAME
#define W_MAP_STORAGE_FUNC_TN(TYPE, NAME) W_MAP_STORAGE_FUNC_TN_(TYPE, NAME)
#define W_MAP_STORAGE_FUNC(NAME) W_MAP_STORAGE_FUNC_TN(CAP_TYPE, NAME)

/* Name and id in Lua */
#define LUA_MAP_STORAGE_NAME_T_(TYPE) "torch." #TYPE "MapStorage"
#define LUA_MAP_STORAGE_NAME_T(TYPE) LUA_MAP_STORAGE_NAME_T_(TYPE)
#define LUA_MAP_STORAGE W_MAP_STORAGE_FUNC(id)

/* Wrapper function name for a Storage */
#define W_STORAGE_FUNC_TN_(TYPE, NAME) torch_##TYPE##Storage_##NAME
#define W_STORAGE_FUNC_TN(TYPE, NAME) W_STORAGE_FUNC_TN_(TYPE, NAME)
#define W_STORAGE_FUNC(NAME) W_STORAGE_FUNC_TN(CAP_TYPE, NAME)

/* Name and id in Lua */
#define LUA_STORAGE_NAME_T_(TYPE) "torch." #TYPE "Storage"
#define LUA_STORAGE_NAME_T(TYPE) LUA_STORAGE_NAME_T_(TYPE)
#define LUA_STORAGE W_STORAGE_FUNC(id)

#if defined(_WIN32) || defined(HAVE_MMAP)

static int W_MAP_STORAGE_FUNC(new)(lua_State *L)
{
  const char *fname = luaL_checkstring(L, 1);
  STORAGE *storage = NULL;
  long size;

  /* check size */
  FILE *f = fopen(fname, "rb");
  if(f == NULL)
    luaL_error(L, "unable to open file for mapping");
  fseek(f, 0, SEEK_END);
  size = ftell(f);
  fclose(f);
  size /= sizeof(TYPE);

#ifdef _WIN32
  {
    HANDLE hfile;
    HANDLE hmfile;
    DWORD size_hi, size_lo;

    /* open file */
    hfile = CreateFileA(fname, GENERIC_READ|GENERIC_WRITE, FILE_SHARE_WRITE|FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

    if (hfile == NULL)
      luaL_error(L,"could not open file %s", fname);

#if SIZEOF_SIZE_T > 4
    size_hi = (DWORD)((size*sizeof(TYPE)) >> 32);
    size_lo = (DWORD)((size*sizeof(TYPE)) & 0xFFFFFFFF);
#else
    size_hi = 0;
    size_lo = (DWORD)(size*sizeof(TYPE));
#endif

    /* get map handle */
    if( (hmfile = CreateFileMapping(hfile, NULL, PAGE_READWRITE, size_hi, size_lo, NULL)) == NULL )
      luaL_error(L,"could not create a map on file %s", fname);

    /* map the stuff */
    storage = STORAGE_FUNC(new)();
    storage->data = MapViewOfFile(hmfile, FILE_MAP_ALL_ACCESS, 0, 0, 0);
    storage->size = size;
    if(storage->data == NULL)
    {
      STORAGE_FUNC(free)(storage);
      luaL_error(L, "memory map failed");      
    }
    CloseHandle(hfile); 
    CloseHandle(hmfile); 
  }
#else
  {
    /* open file */
    int fd = open(fname, O_RDWR, S_IROTH);
    if(fd == -1)
      luaL_error(L, "unable to create shared memory file");
    
    /* map it */
    storage = STORAGE_FUNC(new)();
    storage->data = mmap(NULL, size*sizeof(TYPE), PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    storage->size = size;
    if(storage->data == MAP_FAILED)
    {
      storage->data = NULL; /* let's be sure it is NULL before calling free() */
      STORAGE_FUNC(free)(storage);
      luaL_error(L, "memory map failed");
    }
    close (fd);
  }
#endif

  luaT_pushudata(L, storage, LUA_MAP_STORAGE);
  return 1;
}

static int W_MAP_STORAGE_FUNC(free)(lua_State *L)
{
  STORAGE *storage = luaT_checkudata(L, 1, LUA_MAP_STORAGE);

#ifdef _WIN32
  if(!UnmapViewOfFile((LPINT)storage->data))
#else
  if (munmap(storage->data, storage->size*sizeof(TYPE)))
#endif
    luaL_error(L, "could not unmap the shared memory file");

  storage->data = NULL;
  STORAGE_FUNC(free)(storage);
  return 0;
}

static int W_MAP_STORAGE_FUNC(resize)(lua_State *L)
{
  STORAGE *storage = luaT_checkudata(L, 1, LUA_MAP_STORAGE);
  long size = luaL_checklong(L, 2);

  if(size != storage->size)
    luaL_error(L, "cannot resize a mapped Storage");

  lua_settop(L, 1);
  return 1;
}

static int W_MAP_STORAGE_FUNC(factory)(lua_State *L)
{
  STORAGE *storage = STORAGE_FUNC(new)();
  luaT_pushudata(L, storage, LUA_STORAGE);
  return 1;
}

#ifdef _WIN32
static int W_MAP_STORAGE_FUNC(granularity)(lua_State *L)
{
  SYSTEM_INFO stuff;
  GetSystemInfo(&stuff);
  lua_pushnumber(L, stuff.dwAllocationGranularity);
  return 1;
}
#endif

static const struct luaL_Reg W_MAP_STORAGE_FUNC(_) [] = {
  {"resize", W_MAP_STORAGE_FUNC(resize)},
#ifdef _WIN32
  {"granularity", W_MAP_STORAGE_FUNC(granularity)},
#endif
  {NULL, NULL}
};

void W_MAP_STORAGE_FUNC(init)(lua_State *L)
{
  LUA_STORAGE = luaT_checktypename2id(L, LUA_STORAGE_NAME_T(CAP_TYPE));
  LUA_MAP_STORAGE = luaT_newmetatable(L, LUA_MAP_STORAGE_NAME_T(CAP_TYPE), LUA_STORAGE_NAME_T(CAP_TYPE),
                                      W_MAP_STORAGE_FUNC(new), W_MAP_STORAGE_FUNC(free), W_MAP_STORAGE_FUNC(factory));
  luaL_register(L, NULL, W_MAP_STORAGE_FUNC(_));
  lua_pop(L, 1);
}

#else /* defined(_WIN32) || defined(HAVE_MMAP) */
void W_MAP_STORAGE_FUNC(init)(lua_State *L)
{
}
#endif /* defined(_WIN32) || defined(HAVE_MMAP) */
