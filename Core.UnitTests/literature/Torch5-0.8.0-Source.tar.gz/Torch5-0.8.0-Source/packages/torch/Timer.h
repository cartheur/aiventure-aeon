#ifndef TORCH_TIMER_INC
#define TORCH_TIMER_INC

#include "general.h"

void torch_Timer_init(lua_State *L);

#endif
