#ifndef TORCH_MAP_STORAGE_INC
#define TORCH_MAP_STORAGE_INC

#include "general.h"

/* initializers. assume main table is on the stack */
void torch_CharMapStorage_init(lua_State *L);
void torch_ShortMapStorage_init(lua_State *L);
void torch_IntMapStorage_init(lua_State *L);
void torch_LongMapStorage_init(lua_State *L);
void torch_FloatMapStorage_init(lua_State *L);
void torch_DoubleMapStorage_init(lua_State *L);

#endif
