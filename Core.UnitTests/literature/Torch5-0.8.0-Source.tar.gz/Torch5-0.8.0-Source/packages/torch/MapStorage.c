#include "MapStorage.h"
#include "Storage.h"

#ifdef _WIN32
#include <windows.h>
#endif

#if HAVE_MMAP
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#endif

static const void *torch_CharStorage_id = NULL;
static const void *torch_ShortStorage_id = NULL;
static const void *torch_IntStorage_id = NULL;
static const void *torch_LongStorage_id = NULL;
static const void *torch_FloatStorage_id = NULL;
static const void *torch_DoubleStorage_id = NULL;

static const void *torch_CharMapStorage_id = NULL;
static const void *torch_ShortMapStorage_id = NULL;
static const void *torch_IntMapStorage_id = NULL;
static const void *torch_LongMapStorage_id = NULL;
static const void *torch_FloatMapStorage_id = NULL;
static const void *torch_DoubleMapStorage_id = NULL;

#define TYPE char
#define CAP_TYPE Char
#include "MapStorageGen.c"
#undef TYPE
#undef CAP_TYPE

#define TYPE short
#define CAP_TYPE Short
#include "MapStorageGen.c"
#undef TYPE
#undef CAP_TYPE

#define TYPE int
#define CAP_TYPE Int
#include "MapStorageGen.c"
#undef TYPE
#undef CAP_TYPE

#define TYPE long
#define CAP_TYPE Long
#include "MapStorageGen.c"
#undef TYPE
#undef CAP_TYPE

#define TYPE float
#define CAP_TYPE Float
#include "MapStorageGen.c"
#undef TYPE
#undef CAP_TYPE

#define TYPE double
#define CAP_TYPE Double
#include "MapStorageGen.c"
#undef TYPE
#undef CAP_TYPE
