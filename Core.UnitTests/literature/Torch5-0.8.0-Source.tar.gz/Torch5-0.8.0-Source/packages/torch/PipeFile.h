#ifndef TORCH_PIPE_FILE_INC
#define TORCH_PIPE_FILE_INC

#include "general.h"

void torch_PipeFile_init(lua_State *L);

#endif
