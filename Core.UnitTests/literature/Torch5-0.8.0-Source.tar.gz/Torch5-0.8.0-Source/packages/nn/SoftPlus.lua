local SoftPlus = torch.class('nn.SoftPlus', 'nn.Module')
