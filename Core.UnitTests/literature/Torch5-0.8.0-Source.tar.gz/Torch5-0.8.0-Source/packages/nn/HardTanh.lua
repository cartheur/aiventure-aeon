local HardTanh = torch.class('nn.HardTanh', 'nn.Module')
