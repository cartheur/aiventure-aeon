local Exp = torch.class('nn.Exp', 'nn.Module')
