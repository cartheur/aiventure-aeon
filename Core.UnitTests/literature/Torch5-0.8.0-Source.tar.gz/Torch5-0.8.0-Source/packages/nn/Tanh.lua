local Tanh = torch.class('nn.Tanh', 'nn.Module')
