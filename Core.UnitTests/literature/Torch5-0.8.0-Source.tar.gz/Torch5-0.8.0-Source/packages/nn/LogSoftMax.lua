local LogSoftMax = torch.class('nn.LogSoftMax', 'nn.Module')
