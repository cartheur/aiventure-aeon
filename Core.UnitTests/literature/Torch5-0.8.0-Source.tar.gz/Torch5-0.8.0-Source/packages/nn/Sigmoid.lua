local Sigmoid = torch.class('nn.Sigmoid', 'nn.Module')
