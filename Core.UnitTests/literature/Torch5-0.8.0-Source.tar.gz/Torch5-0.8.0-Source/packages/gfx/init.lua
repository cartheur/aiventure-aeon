require('torch')



dofile(torch.packageLuaPath('gfx') .. '/libgfx.lua')
