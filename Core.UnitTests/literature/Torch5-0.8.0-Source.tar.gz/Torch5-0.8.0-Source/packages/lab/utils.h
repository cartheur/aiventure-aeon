#include "luaT.h"
#include "TH.h"

THLongStorage* lab_checklongargs(lua_State *L, int index);

