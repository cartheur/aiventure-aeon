require "torch"
require "liblab"

dofile(torch.packageLuaPath('lab') .. '/liblab.lua')

