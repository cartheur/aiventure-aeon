#ifndef _LCAIRO_HDEF2
#define _LCAIRO_HDEF2


typedef struct _tImage{

 unsigned char *data;
 cairo_surface_t* surf;

} tImage;

#endif /* _LCAIRO_HDEF */
